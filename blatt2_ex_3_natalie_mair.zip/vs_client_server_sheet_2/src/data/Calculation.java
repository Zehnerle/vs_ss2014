package data;

import java.io.Serializable;

/**
 * @author Alex Untertrifaller
 * 
 *         This class is used for sending calculation data between server and
 *         client.
 * 
 */
public class Calculation implements Serializable {

	private static final long serialVersionUID = 4839884204212897121L;

	// witch operation to proceed on the server
	private final int operation;
	// the first number
	private final int operand1;
	// the second number
	private int operand2;
	// the result from the server
	private int result;

	public Calculation(int operation, int operand1, int operand2) {
		super();
		this.operation = operation;
		this.operand1 = operand1;
		this.operand2 = operand2;
	}

	public int getOperation() {
		return operation;
	}

	public int getOperand1() {
		return operand1;
	}

	public int getOperand2() {
		return operand2;
	}

	public void setOperand2(int i) {
		this.operand2 = i;
	}

	public void setResult(int i) {
		this.result = i;
	}

	public int getResult() {
		return this.result;
	}

}
