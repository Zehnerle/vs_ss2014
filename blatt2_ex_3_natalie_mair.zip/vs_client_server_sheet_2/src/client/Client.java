package client;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.Socket;

import protocol.Protocol;
import data.Calculation;

/**
 * @author Alex Untertrifaller
 * 
 *         The Client class starts a GUI and send requests to the Server.
 * 
 */
public class Client {

	private clientGUI gui;
	private Socket clientSocket = null;
	private final Protocol protocol = new Protocol();

	// private int connectionTys = 0;
	public static void main(String[] args) {
		new Client();
	}

	public Client() {
		// Initialize the GUI for the client
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				gui = new clientGUI();
				gui.setVisibleWhenConnected(false);
				gui.setConnectionText("Not connected");

				// Add Listener for Button Connect
				gui.getbtnConnection().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						connect(gui.getIPAddress(), gui.getUserName(), gui.getPassword());
					}
				});

				// Add Listener for Button Disconnect
				gui.getbtnDisconnect().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						gui.setConnectionText("Not connected");
						// sets the buttons for calculation to disabled
						gui.setVisibleWhenConnected(false);
						// send request for closing connection to server
						protocol.requestCloseConnection(clientSocket);
						disconnect();
					}
				});

				// Add Listener for Button Send
				gui.getbtnSend().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// send the operation and the two operands to the
						// server for calculating the result
						requestHandling(gui.getOperand(), gui.getNumber1(), gui.getNumber2());

					}
				});
			}
		});
	}

	// Connects to the Server
	private void connect(String server, String name, String password) {
		try {
			// create new socket
			clientSocket = new Socket(server, protocol.getPort());

			// sends a user authentification to the server. return true if user
			// is alowed to access to the server
			if (!protocol.requestUserAuthentification(clientSocket, name, password)) {
				clientSocket.close();
				clientSocket = null;
				gui.setConnectionText("Username or password wrong");
			} else {
				gui.setVisibleWhenConnected(true);
				gui.setConnectionText("Connected to " + server);
			}
			// connectionTys++;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// disconnects from the server by closing the socket
	private void disconnect() {
		try {
			clientSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Generates a Message Object from the input Data and sends it to the
	// Server. The Server calculate the result and send that back to the client.
	private void requestHandling(int operation, int operand1, int operand2) {
		Calculation message = new Calculation(operation, operand1, operand2);
		int erg = protocol.request(clientSocket, message);
		gui.setAnswer(String.valueOf(erg));

	}
}
