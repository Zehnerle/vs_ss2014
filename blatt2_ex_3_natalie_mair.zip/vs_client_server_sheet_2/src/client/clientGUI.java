package client;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 * @author Alex Untertrifaller
 * 
 *         A GUI for interacting with the server
 * 
 */
public class clientGUI {

	private JFrame frame;
	private JTextField textFieldIPAddress;
	private JTextField textFieldUsername;
	private JTextField textFieldNumber1;
	private JTextField textFieldNumber2;
	private JTextField textFieldAnswer;
	private JComboBox<String> comboBoxOperand;
	private JButton btnSend;
	private JButton btnConnect;
	private JButton btnDisconnect;
	private JLabel labelConnection;
	private JLabel lblPassword;
	private JTextField textFieldPassword;

	/**
	 * Create the application.
	 */
	public clientGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 456, 474);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		textFieldIPAddress = new JTextField();
		textFieldIPAddress.setText("localhost");
		textFieldIPAddress.setBounds(158, 71, 223, 19);
		frame.getContentPane().add(textFieldIPAddress);
		textFieldIPAddress.setColumns(10);

		JLabel lblClient = new JLabel("Client");
		lblClient.setFont(new Font("Dialog", Font.BOLD, 24));
		lblClient.setBounds(186, 12, 145, 26);
		frame.getContentPane().add(lblClient);

		JLabel lblIpAddress = new JLabel("IP Address");
		lblIpAddress.setBounds(51, 73, 97, 15);
		frame.getContentPane().add(lblIpAddress);

		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(51, 100, 97, 15);
		frame.getContentPane().add(lblUsername);

		textFieldUsername = new JTextField();
		textFieldUsername.setBounds(158, 98, 223, 19);
		frame.getContentPane().add(textFieldUsername);
		textFieldUsername.setColumns(10);

		comboBoxOperand = new JComboBox<String>();
		comboBoxOperand.setModel(new DefaultComboBoxModel<String>(new String[] { "+", "-", "*", "fib" }));
		comboBoxOperand.setBounds(158, 266, 114, 24);
		frame.getContentPane().add(comboBoxOperand);

		comboBoxOperand.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (comboBoxOperand.getSelectedIndex() == 3) {
					textFieldNumber2.setEnabled(false);
					textFieldNumber2.setText("0");
				} else
					textFieldNumber2.setEnabled(true);
			}
		});

		JLabel lblOperand = new JLabel("Operand");
		lblOperand.setBounds(51, 271, 70, 15);
		frame.getContentPane().add(lblOperand);

		textFieldNumber1 = new JTextField();
		textFieldNumber1.setBounds(158, 300, 114, 19);
		frame.getContentPane().add(textFieldNumber1);
		textFieldNumber1.setColumns(10);
		((AbstractDocument) textFieldNumber1.getDocument()).setDocumentFilter(new MyDocumentFilter());

		textFieldNumber2 = new JTextField();
		textFieldNumber2.setBounds(158, 333, 114, 19);
		frame.getContentPane().add(textFieldNumber2);
		textFieldNumber2.setColumns(10);
		((AbstractDocument) textFieldNumber2.getDocument()).setDocumentFilter(new MyDocumentFilter());

		JLabel lblNumber = new JLabel("Number 1");
		lblNumber.setBounds(51, 304, 70, 15);
		frame.getContentPane().add(lblNumber);

		JLabel lblNumber_1 = new JLabel("Number 2");
		lblNumber_1.setBounds(51, 335, 70, 15);
		frame.getContentPane().add(lblNumber_1);

		btnSend = new JButton("Send");
		btnSend.setBounds(158, 364, 114, 25);
		frame.getContentPane().add(btnSend);

		textFieldAnswer = new JTextField();
		textFieldAnswer.setBounds(158, 401, 114, 19);
		textFieldAnswer.setEditable(false);
		frame.getContentPane().add(textFieldAnswer);
		textFieldAnswer.setColumns(10);

		JLabel lblAnswer = new JLabel("Answer");
		lblAnswer.setBounds(51, 403, 70, 15);
		frame.getContentPane().add(lblAnswer);

		btnConnect = new JButton("Connect");
		btnConnect.setBounds(158, 192, 97, 25);
		frame.getContentPane().add(btnConnect);

		labelConnection = new JLabel("not connected");
		labelConnection.setBounds(158, 165, 261, 15);
		frame.getContentPane().add(labelConnection);

		JLabel lblInfo = new JLabel("info");
		lblInfo.setBounds(51, 165, 70, 15);
		frame.getContentPane().add(lblInfo);

		btnDisconnect = new JButton("Disconnect");
		btnDisconnect.setBounds(267, 192, 114, 25);
		frame.getContentPane().add(btnDisconnect);

		JSeparator separator = new JSeparator();
		separator.setBounds(12, 243, 430, 2);
		frame.getContentPane().add(separator);

		lblPassword = new JLabel("Password");
		lblPassword.setBounds(51, 125, 70, 15);
		frame.getContentPane().add(lblPassword);

		textFieldPassword = new JTextField();
		textFieldPassword.setBounds(158, 123, 223, 19);
		frame.getContentPane().add(textFieldPassword);
		textFieldPassword.setColumns(10);
	}

	public String getIPAddress() {
		return textFieldIPAddress.getText();
	}

	public String getUserName() {
		return textFieldUsername.getText();
	}

	public int getNumber1() {
		return Integer.parseInt(textFieldNumber1.getText());
	}

	public int getNumber2() {
		return Integer.parseInt(textFieldNumber2.getText());
	}

	public int getOperand() {
		return comboBoxOperand.getSelectedIndex();
	}

	public JButton getbtnSend() {
		return btnSend;
	}

	public void setConnectionText(String text) {
		labelConnection.setText(text);
	}

	public JButton getbtnConnection() {
		return btnConnect;
	}

	public JButton getbtnDisconnect() {
		return btnDisconnect;
	}

	public void setAnswer(String text) {
		textFieldAnswer.setText(text);
	}

	public void setVisibleWhenConnected(boolean visible) {
		this.comboBoxOperand.setEnabled(visible);
		this.textFieldNumber1.setEnabled(visible);
		this.textFieldNumber2.setEnabled(visible);
		this.btnSend.setEnabled(visible);
		this.textFieldAnswer.setEnabled(visible);
	}

	public void setVisibleNumber2(boolean visible) {
		this.textFieldNumber2.setEnabled(visible);
	}

	public String getPassword() {
		return this.textFieldPassword.getText();
	}
}

// Looks on a TextBox to allow only numbers to insert in the field. No other
// digits are allowed.
class MyDocumentFilter extends DocumentFilter {
	@Override
	public void insertString(DocumentFilter.FilterBypass fp, int offset, String string, AttributeSet aset) throws BadLocationException {
		int len = string.length();
		boolean isValidInteger = true;

		for (int i = 0; i < len; i++) {
			if (!Character.isDigit(string.charAt(i))) {
				isValidInteger = false;
				break;
			}
		}
		if (isValidInteger)
			super.insertString(fp, offset, string, aset);
		else
			Toolkit.getDefaultToolkit().beep();
	}

	@Override
	public void replace(DocumentFilter.FilterBypass fp, int offset, int length, String string, AttributeSet aset) throws BadLocationException {
		int len = string.length();
		boolean isValidInteger = true;

		for (int i = 0; i < len; i++) {
			if (!Character.isDigit(string.charAt(i))) {
				isValidInteger = false;
				break;
			}
		}
		if (isValidInteger)
			super.replace(fp, offset, length, string, aset);
		else
			Toolkit.getDefaultToolkit().beep();
	}
}
