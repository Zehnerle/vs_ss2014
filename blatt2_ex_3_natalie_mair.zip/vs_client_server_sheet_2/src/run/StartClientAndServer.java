package run;

import server.Server;
import client.Client;

/**
 * @author Alex Untertrifaller
 * 
 *         Starts the server and client.
 * 
 */
public class StartClientAndServer {

	public static void main(String[] args) {
		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				new Server();
			}
		});
		t.start();

		new Client();

	}

}
