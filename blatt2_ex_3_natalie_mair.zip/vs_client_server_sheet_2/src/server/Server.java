package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import protocol.Protocol;

/**
 * @author Alex Untertrifaller
 * 
 *         The Server Class runns a Server that will wait to a client and will
 *         interact with them.
 * 
 */
public class Server {

	public static void main(String[] args) {
		new Server();
	}

	public Server() {
		Protocol protocol = new Protocol();
		ServerSocket serverSocket = null;
		Socket connectionSocket = null;
		boolean answer = false;

		try {
			System.out.println(" -------------------------------");
			System.out.println("/\tServer running \t\t/");
			System.out.println(" -------------------------------");

			// create new ServerSocket.
			serverSocket = new ServerSocket(protocol.getPort());
			// Runs until get killed by the user.
			while (true) {
				do {
					// wait to a client
					connectionSocket = serverSocket.accept();
					System.out.println(connectionSocket.getRemoteSocketAddress().toString() + " -- Wait for user authentication");
					// check if user is authorized to interact with the server
					// else wait for other clients
					answer = protocol.replayUserAuthentification(connectionSocket);
					if (answer == false)
						System.out.println(connectionSocket.getRemoteSocketAddress().toString() + " -- Acces denied! User not authenticated");
				} while (answer == false);

				// if client is authorized than connect
				System.out.println(connectionSocket.getRemoteSocketAddress().toString() + " -- Acces acepted! User authenticated");
				System.out.println(connectionSocket.getRemoteSocketAddress().toString() + " -- Server connected");
				// answer to the request of the server
				protocol.replay(connectionSocket);

			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// Close all connections
			try {
				connectionSocket.close();
				serverSocket.close();

				System.out.println(" -------------------------------");
				System.out.println("/\tServer stoped \t\t/");
				System.out.println(" -------------------------------");
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}
}
