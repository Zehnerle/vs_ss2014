package protocol;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import data.Calculation;
import data.User;

/**
 * @author Alex Untertrifaller
 * 
 *         Protocol to interact between server and client.
 * 
 */
public class Protocol {

	// port of the socket.
	private final static int PORT = 1253;

	private final static int ADD = 0;
	private final static int SUB = 1;
	private final static int MUL = 2;
	private final static int FIB = 3;
	private final static int EXIT = 4;

	// list of the users that are allowed to interact with the server
	private final List<User> usernames;

	public Protocol() {
		// setup user name and password of the allowed users
		usernames = new ArrayList<User>();
		usernames.add(new User("alex", "seppl"));
		usernames.add(new User("alexander", "seppl"));
		usernames.add(new User("natalie", "seppl"));
	}

	// Send a request to the server. Containing the operand and the two numbers.
	public int request(Socket clientSocket, Calculation message) {
		try {
			// send request to server.
			ObjectOutputStream outToServer = new ObjectOutputStream(clientSocket.getOutputStream());
			outToServer.writeObject(message);

			// read answer from server
			ObjectInputStream input = new ObjectInputStream(clientSocket.getInputStream());
			message = (Calculation) input.readObject();

			return message.getResult();

		} catch (IOException e) {
			e.printStackTrace();
			return -1;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return -1;
		}
	}

	// Send the result back to the server. Runs in a thread so that more then
	// one client can interact with the server.
	public void replay(final Socket serverSocket) {
		// create thread to handle multiple clients.
		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				ObjectInputStream input = null;
				ObjectOutputStream outToServer = null;
				boolean run = true;

				while (run) {
					try {
						// read recived object and calculate result.
						input = new ObjectInputStream(serverSocket.getInputStream());
						Calculation message = (Calculation) input.readObject();
						// if the operation is 4 than the server should stop
						// handling new requests.
						if (message.getOperation() == EXIT)
							run = false;
						else {
							// calculate result
							int erg = result(message);
							System.out.println(serverSocket.getRemoteSocketAddress().toString() + " -- erg = " + erg);
							// send result back to client.
							outToServer = new ObjectOutputStream(serverSocket.getOutputStream());
							message.setResult(erg);
							outToServer.writeObject(message);
						}
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				try {
					// close all connections and streams
					System.out.println(serverSocket.getRemoteSocketAddress().toString() + " -- Client disconnected");
					input.close();
					// if no request was send to the client and it wants to
					// disconnect than it could happen that the outToSErver
					// Object is not initialized.
					if (outToServer != null)
						outToServer.close();
					serverSocket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		});
		t.start();

	}

	// Request to the server if the user is allowed to interact with the server.
	public boolean requestUserAuthentification(Socket client, String name, String password) {
		try {
			// send user name and password to the server
			User requestMessage = new User(name, password);
			ObjectOutputStream outToServer = new ObjectOutputStream(client.getOutputStream());
			outToServer.writeObject(requestMessage);

			// recive result from the server
			ObjectInputStream input = new ObjectInputStream(client.getInputStream());
			User returnMessage = (User) input.readObject();
			return returnMessage.isAccept();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}

	}

	// send answer to the client if the user is allowed to interact with the
	// server.
	public boolean replayUserAuthentification(Socket server) {

		ObjectInputStream input;
		try {
			// read MessageUser from the client
			input = new ObjectInputStream(server.getInputStream());
			User message = (User) input.readObject();

			// Check user name and password
			message.setAccept(false);
			for (User m : usernames) {
				if (m.equals(message))
					message.setAccept(true);
			}

			// writes the answer to the client
			ObjectOutputStream outToServer = new ObjectOutputStream(server.getOutputStream());
			outToServer.writeObject(message);

			// returns true if isAccepted so that the server knows if it was
			// accepted or not.
			if (message.isAccept())
				return true;
			else {
				server.close();
				return false;
			}
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
	}

	// client will send a request to the server for closing the connection.
	public void requestCloseConnection(Socket client) {
		try {
			ObjectOutputStream outToServer = new ObjectOutputStream(client.getOutputStream());
			Calculation message = new Calculation(EXIT, 0, 0);
			outToServer.writeObject(message);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// calculate the result for the different operations
	private int result(Calculation message) {
		if (message.getOperation() == ADD) {
			return message.getOperand1() + message.getOperand2();
		} else if (message.getOperation() == SUB) {
			return message.getOperand1() - message.getOperand2();
		} else if (message.getOperation() == MUL) {
			return message.getOperand1() * message.getOperand2();
		} else if (message.getOperation() == FIB) {
			return fib(message.getOperand1());
		} else
			return -1;
	}

	// calculate fibonacci recursive
	private int fib(int n) {
		if (n == 0)
			return 0;
		else if (n == 1)
			return 1;
		else
			return fib(n - 1) + fib(n - 2);
	}

	// return port
	public int getPort() {
		return PORT;
	}

}
